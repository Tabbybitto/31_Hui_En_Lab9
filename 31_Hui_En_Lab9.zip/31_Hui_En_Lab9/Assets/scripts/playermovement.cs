﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class playermovement : MonoBehaviour
{   
    public int jumpht;
    public Rigidbody rb;

    public int points;
    public Text score;
    public Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position = new Vector3(0,Mathf.Clamp(transform.position.y,-5.5f,4.6f),0);
        if (Input.GetKeyDown(KeyCode.Space)|| Input.GetKeyDown(KeyCode.Mouse0))
        {
            rb.AddForce(new Vector3(rb.velocity.x,jumpht,rb.velocity.z));
            anim.SetTrigger("flap");
        }
    }
   
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "death")
        {
            SceneManager.LoadScene("GO");
        }
        if (other.gameObject.tag == "points")
        {
            points++;
            score.text = "Score: "+ points;
        }
    }
}
