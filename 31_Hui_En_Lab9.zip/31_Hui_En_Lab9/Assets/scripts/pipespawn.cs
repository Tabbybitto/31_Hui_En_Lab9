﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pipespawn : MonoBehaviour
{
    public GameObject pipes;
    public float spwnr;
    public float minht;
    public float maxht;
    // Start is called before the first frame update
    void OnEnable()
    {
        InvokeRepeating(nameof(Spawn),spwnr,spwnr);
    }
    void OnDisable()
    {
        CancelInvoke(nameof(Spawn));
    }
    void Spawn()
    {
        GameObject pipesobstacles = Instantiate(pipes,transform.position,Quaternion.identity);
        pipesobstacles.transform.position += Vector3.up * Random.Range(minht,maxht);
    }

}
