﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameramovement : MonoBehaviour
{
    public Transform target;
    public float offset;
    private void LateUpdate()
    {
        transform.position = new Vector3(target.position.x + offset, this.transform.position.y,this.transform.position.z);
    }
}
